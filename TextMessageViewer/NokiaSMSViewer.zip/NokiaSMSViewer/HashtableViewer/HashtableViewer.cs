using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Bhavesh.Utilities;

namespace HashtableViewer
{
	/// <summary>
	/// Summary description for HashtableViewer.
	/// </summary>
	public class HashtableViewer : System.Windows.Forms.Form
	{
		private ListViewColumnSorter lvwColumnSorter = new ListViewColumnSorter();
		private System.Windows.Forms.ListView listview;
		private Hashtable hashtable;
		private System.Windows.Forms.ColumnHeader colHKey;
		private System.Windows.Forms.ColumnHeader colHValue;
		private System.Windows.Forms.TextBox textBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public HashtableViewer(Hashtable _hashtable)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			hashtable = _hashtable;

//			System.IO.StreamWriter writer = new System.IO.StreamWriter(@"C:\Documents and Settings\Bhavesh Patel\My Documents\Nokia\Messages\Contacts\Contacts.txt");
//			string[] keys = new string[hashtable.Keys.Count], values  = new string[hashtable.Keys.Count];
//			hashtable.Keys.CopyTo(keys,0);
//			hashtable.Values.CopyTo(values,0);
//
//			Array.Sort( values,keys);
//
//			for (int i =0;i<values.Length;i++)
//			{
//				writer.WriteLine(values[i]+"(" +keys[i]+ ")");
//			}
//			writer.Close();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.listview = new System.Windows.Forms.ListView();
			this.colHKey = new System.Windows.Forms.ColumnHeader();
			this.colHValue = new System.Windows.Forms.ColumnHeader();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// listview
			// 
			this.listview.AllowDrop = true;
			this.listview.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																					   this.colHKey,
																					   this.colHValue});
			this.listview.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listview.FullRowSelect = true;
			this.listview.HideSelection = false;
			this.listview.Location = new System.Drawing.Point(0, 0);
			this.listview.Name = "listview";
			this.listview.Size = new System.Drawing.Size(292, 266);
			this.listview.TabIndex = 0;
			this.listview.View = System.Windows.Forms.View.Details;
			this.listview.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listview_ColumnClick);
			this.listview.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.listview_ItemDrag);
			// 
			// colHKey
			// 
			this.colHKey.Text = "Key";
			this.colHKey.Width = 144;
			// 
			// colHValue
			// 
			this.colHValue.Text = "Value";
			this.colHValue.Width = 141;
			// 
			// textBox1
			// 
			this.textBox1.AllowDrop = true;
			this.textBox1.Location = new System.Drawing.Point(88, 24);
			this.textBox1.Name = "textBox1";
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "textBox1";
			this.textBox1.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox1_DragDrop);
			this.textBox1.DragEnter += new System.Windows.Forms.DragEventHandler(this.textBox1_DragEnter);
			// 
			// HashtableViewer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.listview);
			this.Name = "HashtableViewer";
			this.Text = "HashtableViewer";
			this.Load += new System.EventHandler(this.HashtableViewer_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void listview_ColumnClick(object sender, System.Windows.Forms.ColumnClickEventArgs e)
		{
			// Determine if clicked column is already the column that is being sorted.
			if ( e.Column == lvwColumnSorter.SortColumn )
			{
				// Reverse the current sort direction for this column.
				if (lvwColumnSorter.Order == SortOrder.Ascending)
				{
					lvwColumnSorter.Order = SortOrder.Descending;
				}
				else
				{
					lvwColumnSorter.Order = SortOrder.Ascending;
				}
			}
			else
			{
				// Set the column number that is to be sorted; default to ascending.
				lvwColumnSorter.SortColumn = e.Column;
				lvwColumnSorter.Order = SortOrder.Ascending;
			}

			// Perform the sort with these new sort options.
			listview.Sort();

		}

		private void HashtableViewer_Load(object sender, System.EventArgs e)
		{
			listview.ListViewItemSorter = lvwColumnSorter;
			foreach(string number in hashtable.Keys)
			{
				listview.Items.Add(new ListViewItem(new string[]{(string)hashtable[number],number}));
			}

			ListViewColumnSorter.SortListView(listview, 0);
		}

		private void listview_ItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
		{
			DoDragDrop(e.Item, DragDropEffects.Copy);
		}

		private void textBox1_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
		{
			if (e.Data.GetData("System.Windows.Forms.ListViewItem", true) != null)
			{
				e.Effect = DragDropEffects.Copy;
			}
			else	
			{
				e.Effect = DragDropEffects.None;
			}
		}

		private void textBox1_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
		{
			textBox1.Text = ((ListViewItem)e.Data.GetData("System.Windows.Forms.ListViewItem", true)).SubItems[1].Text;
		
		}
	}
}
