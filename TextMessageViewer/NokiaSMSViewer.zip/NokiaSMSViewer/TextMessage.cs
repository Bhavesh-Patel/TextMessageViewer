using System;
using System.Collections.Generic;
using System.IO;

namespace NokiaSMSViewer
{
	/// <summary>Summary description for TextMessage.</summary>
	public class TextMessage : Object
	{
		#region Fields
		/// <summary>Text of message.</summary>
		protected string message;

		/// <summary>Date and time of message.</summary>
		protected DateTime dateTime;

		/// <summary>Number of sender or reciever of message.</summary>
		protected string number;

		/// <summary>Message status.</summary>
		protected MessageStatus sentOrRecieved;
		#endregion

		#region Public Properties
		/// <summary>Gets the text of message.</summary>
		public string Message
		{
			get { return message; }
		}

		/// <summary>Gets the date and time of message.</summary>
		public DateTime DateTime
		{
			get { return dateTime; }
		}

		/// <summary>Gets the number of sender or reciever of message.</summary>
		public string Number
		{
			get { return number; }
		}

		/// <summary>Gets the message status.</summary>
		public MessageStatus Status
		{
			get { return sentOrRecieved; }
		}
		#endregion

		#region Constructors
		/// <summary>Initializes a new instance of the <see cref="TextMessage"/> class.</summary>
		/// <param name="_message">The _message.</param>
		/// <param name="_number">The _number.</param>
		/// <param name="_dateTime">The _date time.</param>
		/// <param name="_sentOrRecieved">The _sent or recieved.</param>
		public TextMessage(string _message, string _number, DateTime _dateTime, MessageStatus _sentOrRecieved)
		{
			message = _message;
			number = _number;
			sentOrRecieved = _sentOrRecieved;
			dateTime = _dateTime;
		}
		#endregion

		#region Public Methods
		/// <summary>Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.</summary>
		/// <returns>A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.</returns>
		public override string ToString()
		{
			return message;
		}
		#endregion

		#region Static Methods
		/// <summary>Creates a <see cref="TextMessage"/> from a file containing data.</summary>
		/// <param name="filePath">The file path.</param>
		/// <param name="format">The format of the file to be read.</param>
		/// <returns>A TextMessage containing all relevant information from the file.</returns>
		public static TextMessage ReadTextMessage(string filePath, MessageFormats.MessageFormat format)
		{
			TextMessage result;
			switch (format) {
				case MessageFormats.MessageFormat.Nokia: {
						result = ReadNokiaTextMessage(filePath);
						break;
					}
				case MessageFormats.MessageFormat.Motorola: {
						result = ReadMotorolaTextMessage(filePath);
						break;
					}
				default:
					throw new NotImplementedException("Unable to read " + format.ToString() + "...yet!");
			}
			return result;
		}

		/// <summary>Creates a <see cref="TextMessage"/> from a file containing data, in Nokia format.</summary>
		/// <param name="filePath">The file path.</param>
		/// <returns>A TextMessage containing all relevant information from the file.</returns>
		private static TextMessage ReadNokiaTextMessage(string filePath)
		{
			StreamReader sr = new StreamReader(filePath);

			//read in whole file removing \0 (null) and \r, and store lines in an array
			List<string> items = new List<string>(sr.ReadToEnd().Replace("\0", "").Replace("\r", "").Split(new char[] { '\n' }));
			sr.Close();
			int index = 0, maxIndex = items.Count;

			//find first line starting with TEL:
			while (index < maxIndex && !items[index].StartsWith("TEL:"))
				index++;

			//From number line
			string fromNum = items[index].Substring(4);

			//change between version 3 and 2.1: only single number stored
			//for backward compatibility try to find 2nd number, if first was empty.
			string toNum = String.Empty;
			if (fromNum == "") {
				while (index < maxIndex && !items[++index].StartsWith("TEL:")) ;
				//index++;
				//To number line
				toNum = items[index].Substring(4);
			}

			//find line starting with Date:
			while (index < maxIndex && !items[index].StartsWith("Date:"))
				index++;

			//Date line
			DateTime dt = DateTime.Parse(items[index].Substring(5));
			string dateTime = items[index];

			//Message line
			string message = items[++index];
			string tmp = items[++index];
			while (index + 1 < maxIndex && tmp != null && !tmp.StartsWith("END"))//checking for multi line messages
			{
				message += "\r\n" + tmp;
				tmp = items[++index];
			}

			bool isSentMessage = String.IsNullOrEmpty(fromNum) && !String.IsNullOrEmpty(toNum);
			string textMessageNumber = isSentMessage ? toNum : fromNum;
			MessageStatus textMessageStatus = isSentMessage ? MessageStatus.Sent : MessageStatus.Recieved;
			TextMessage textMessage = new TextMessage(message, textMessageNumber, dt, textMessageStatus);

			return textMessage;
		}

		/// <summary>Creates a <see cref="TextMessage"/> from a file containing data, in Motorola format.</summary>
		/// <remarks>The text file doesn't contain infomation to indicate whether it was sent or recieved.</remarks>
		/// <param name="filePath">The file path.</param>
		/// <returns>A TextMessage containing all relevant information from the file.</returns>
		private static TextMessage ReadMotorolaTextMessage(string filePath)
		{
			//string path = lblPath.Text + "\\"+ e.Node.Text;
			StreamReader sr = new StreamReader(filePath);

			//From/To number line = 1
			string contact = sr.ReadLine().Replace("\0", "");

			//date line = 2
			string dateTime = sr.ReadLine().Replace("\0", "");
			DateTime dt = DateTime.Parse(dateTime.Substring(5));
			string[] dateItems = dateTime.Substring(6).Split(new char[] { '/' });
			try {
				DateTime.Parse(dateTime.Substring(6));
			} catch (FormatException) {
				dateTime = "Date: " + dateItems[1] + "/" + dateItems[0] + "/" + dateItems[2];
			}

			sr.ReadLine();

			//Message line = 4
			string message = sr.ReadLine().Replace("\0", "");

			sr.Close();

			string textMessageNumber = contact.Substring(9);
			MessageStatus textMessageStatus = MessageStatus.Recieved;//can't distingish status from data in text file
			TextMessage textMessage = new TextMessage(message, textMessageNumber, dt, textMessageStatus);

			return textMessage;
		}
		#endregion
	}

	/// <summary>Represents status of a text message.</summary>
	public enum MessageStatus
	{
		/// <summary>Text message recieved.</summary>
		Recieved,
		/// <summary>Text message sent.</summary>
		Sent
	}
}
