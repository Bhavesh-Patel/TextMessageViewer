using System;
using System.Collections.Generic;
using System.Text;

namespace NokiaSMSViewer
{
	class MessageFolder
	{
		#region Fields
		protected string name;

		protected List<TextMessage> messages = new List<TextMessage>();

		protected List<MessageFolder> folders = new List<MessageFolder>(); 
		#endregion

		#region Public Properties
		public string Name
		{
			get { return name; }
		}

		public List<TextMessage> Messages
		{
			get { return messages; }
			set { messages = value; }
		}

		public List<MessageFolder> Folders
		{
			get { return folders; }
			set { folders = value; }
		} 
		#endregion

		#region Constructors
		public MessageFolder(string _name)
		{
			name = _name;
		} 
		#endregion
	}
}
