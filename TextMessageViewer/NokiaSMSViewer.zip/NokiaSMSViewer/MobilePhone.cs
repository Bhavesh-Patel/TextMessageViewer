using System;
using System.Collections.Generic;
using System.Text;

namespace NokiaSMSViewer
{
	class MobilePhone : MessageFolder
	{
		#region Fields
		protected MessageFormats.MessageFormat format;
		#endregion

		#region Public Properties
		public MessageFormats.MessageFormat Format
		{
			get { return format; }
		}

		public List<MessageFolder> Folders
		{
			get { return folders = new List<MessageFolder>(); }
			set { folders = value; }
		}
		#endregion

		#region Constructors
		public MobilePhone(string _name, MessageFormats.MessageFormat _format)
			: base(_name)
		{
			format = _format;
		}
		#endregion
	}
}
