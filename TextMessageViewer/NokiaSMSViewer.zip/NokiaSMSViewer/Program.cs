using System;
using System.Windows.Forms;

namespace NokiaSMSViewer
{
	/// <summary>
	/// Summary description for Program.
	/// </summary>
	public class Program
	{
		public Program()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			//Application.Run(new Form1());
			//Application.Run(new MainBoard());
			Application.Run(new MainBoard2());
		}
	}
}
