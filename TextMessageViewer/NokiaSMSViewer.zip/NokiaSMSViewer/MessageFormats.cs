using System;
using System.Collections;
using System.Collections.Generic;

namespace NokiaSMSViewer
{
	/// <summary>Contains details of each format, including file type and default prefix.</summary>
	public class MessageFormats
	{
		/// <summary>Map of MessageFormat to file extenision.</summary>
		private static Dictionary<MessageFormat, string> formatFileType;
		/// <summary>Map of MessageFormat to standard file prefix.</summary>
		private static Dictionary<MessageFormat, string> formatFilePrefix;

		/// <summary>Static constructor initialises the maps.</summary>
		static MessageFormats()
		{
			formatFileType = new Dictionary<MessageFormat, string>();
			formatFileType[MessageFormat.Motorola] = "txt";
			formatFileType[MessageFormat.Nokia] = "vmg";
			formatFilePrefix = new Dictionary<MessageFormat, string>();
			formatFilePrefix[MessageFormat.Motorola] = "recu";
			formatFilePrefix[MessageFormat.Nokia] = "";
		}

		/// <summary>Retrieves the standard file extension for the given format.</summary>
		/// <param name="format">Format for which the extension is required.</param>
		/// <returns>The standard file extension for the given format.</returns>
		public static string GetExtention(MessageFormat format)
		{
			return formatFileType[format];
		}

		/// <summary>Retrieves the standard file prefix for the given format.</summary>
		/// <param name="format">Format for which the prefix is required.</param>
		/// <returns>The standard file prefix for the given format.</returns>
		public static string GetFilePrefix(MessageFormat format)
		{
			return formatFilePrefix[format];
		}

		/// <summary>Enumeration of different formats.</summary>
		public enum	MessageFormat
		{
			/// <summary>Messages from Nokia phones.</summary>
			Nokia,
			/// <summary>Messages from Motorola phones.</summary>
			Motorola
		}
	}
}
