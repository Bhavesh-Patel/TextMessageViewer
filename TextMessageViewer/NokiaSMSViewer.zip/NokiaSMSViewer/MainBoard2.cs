using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.IO.IsolatedStorage;
using System.Configuration;
using System.Collections.Specialized;
using Bhavesh.Utilities;
using Bhavesh.WindowsControlLibrary;
using System.Collections.Generic;

namespace NokiaSMSViewer
{
	/// <summary>
	/// Summary description for MainBoard2.
	/// </summary>
	public class MainBoard2 : System.Windows.Forms.Form
	{
		#region Auto Generated
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem mnuFile;
		private System.Windows.Forms.MenuItem mnuNo2Names;
		private System.Windows.Forms.MenuItem mnuExit;
		private System.Windows.Forms.TreeView tvParents;
		private System.Windows.Forms.ListView lvChildren;
		private System.Windows.Forms.ColumnHeader colHFrom;
		private System.Windows.Forms.ColumnHeader colHMessage;
		private System.Windows.Forms.ColumnHeader colHDate;
		private System.Windows.Forms.ColumnHeader colHTime;
		private System.Windows.Forms.ColumnHeader colHTo;
		private System.Windows.Forms.ColumnHeader colHFileName;
		private System.Windows.Forms.Button btnRefresh;
		private System.Windows.Forms.Button btnEdit;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnRename;
		private System.Windows.Forms.TextBox txtMessage;
		private System.Windows.Forms.Label lblTime;
		private System.Windows.Forms.Label lblDate;
		private System.Windows.Forms.Label lblFrom;
		private System.Windows.Forms.Label lblTo;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.StatusBar statusBar;
		private System.Windows.Forms.ContextMenu ctxMTreeview;
		private System.Windows.Forms.MenuItem mnuCreateNew;
		private System.Windows.Forms.MenuItem mnuShowContacts;
		private System.Windows.Forms.MenuItem mnuReadAccessDatabase;
		private System.Windows.Forms.ProgressBar progressBar;
		private System.Windows.Forms.ContextMenu ctxMListView;
		private System.Windows.Forms.MenuItem mnuListViewView;
		private System.Windows.Forms.MenuItem mnuListViewEdit;
		private IContainer components;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		public MainBoard2()
		{
			InitializeComponent();
		}

		static MainBoard2()
		{
			path = ConfigurationSettings.AppSettings["InitialFolder"];
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Phones");
			this.mainMenu = new System.Windows.Forms.MainMenu(this.components);
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuNo2Names = new System.Windows.Forms.MenuItem();
			this.mnuShowContacts = new System.Windows.Forms.MenuItem();
			this.mnuReadAccessDatabase = new System.Windows.Forms.MenuItem();
			this.mnuExit = new System.Windows.Forms.MenuItem();
			this.tvParents = new System.Windows.Forms.TreeView();
			this.ctxMTreeview = new System.Windows.Forms.ContextMenu();
			this.mnuCreateNew = new System.Windows.Forms.MenuItem();
			this.lvChildren = new System.Windows.Forms.ListView();
			this.colHFrom = new System.Windows.Forms.ColumnHeader();
			this.colHMessage = new System.Windows.Forms.ColumnHeader();
			this.colHDate = new System.Windows.Forms.ColumnHeader();
			this.colHTime = new System.Windows.Forms.ColumnHeader();
			this.colHTo = new System.Windows.Forms.ColumnHeader();
			this.colHFileName = new System.Windows.Forms.ColumnHeader();
			this.ctxMListView = new System.Windows.Forms.ContextMenu();
			this.mnuListViewView = new System.Windows.Forms.MenuItem();
			this.mnuListViewEdit = new System.Windows.Forms.MenuItem();
			this.btnRefresh = new System.Windows.Forms.Button();
			this.btnEdit = new System.Windows.Forms.Button();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnRename = new System.Windows.Forms.Button();
			this.txtMessage = new System.Windows.Forms.TextBox();
			this.lblTime = new System.Windows.Forms.Label();
			this.lblDate = new System.Windows.Forms.Label();
			this.lblFrom = new System.Windows.Forms.Label();
			this.lblTo = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.statusBar = new System.Windows.Forms.StatusBar();
			this.progressBar = new System.Windows.Forms.ProgressBar();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuFile});
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuNo2Names,
            this.mnuShowContacts,
            this.mnuReadAccessDatabase,
            this.mnuExit});
			this.mnuFile.Text = "File";
			// 
			// mnuNo2Names
			// 
			this.mnuNo2Names.Index = 0;
			this.mnuNo2Names.Text = "Numbers -> Names";
			this.mnuNo2Names.Click += new System.EventHandler(this.mnuNo2Names_Click);
			// 
			// mnuShowContacts
			// 
			this.mnuShowContacts.Index = 1;
			this.mnuShowContacts.Text = "Show Contacts";
			this.mnuShowContacts.Click += new System.EventHandler(this.mnuShowContacts_Click);
			// 
			// mnuReadAccessDatabase
			// 
			this.mnuReadAccessDatabase.Index = 2;
			this.mnuReadAccessDatabase.Text = "Read Access Database";
			this.mnuReadAccessDatabase.Click += new System.EventHandler(this.mnuReadAccessDatabase_Click);
			// 
			// mnuExit
			// 
			this.mnuExit.Index = 3;
			this.mnuExit.Text = "E&xit";
			this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
			// 
			// tvParents
			// 
			this.tvParents.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)));
			this.tvParents.ContextMenu = this.ctxMTreeview;
			this.tvParents.HideSelection = false;
			this.tvParents.Location = new System.Drawing.Point(8, 8);
			this.tvParents.Name = "tvParents";
			treeNode1.Name = "";
			treeNode1.Text = "Phones";
			this.tvParents.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
			this.tvParents.Size = new System.Drawing.Size(136, 408);
			this.tvParents.TabIndex = 0;
			this.tvParents.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvParents_AfterSelect);
			// 
			// ctxMTreeview
			// 
			this.ctxMTreeview.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuCreateNew});
			this.ctxMTreeview.Popup += new System.EventHandler(this.ctxMTreeview_Popup);
			// 
			// mnuCreateNew
			// 
			this.mnuCreateNew.Index = 0;
			this.mnuCreateNew.Text = "Create New";
			this.mnuCreateNew.Click += new System.EventHandler(this.mnuCreateNew_Click);
			// 
			// lvChildren
			// 
			this.lvChildren.Anchor = ((System.Windows.Forms.AnchorStyles) ((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.lvChildren.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colHFrom,
            this.colHMessage,
            this.colHDate,
            this.colHTime,
            this.colHTo,
            this.colHFileName});
			this.lvChildren.ContextMenu = this.ctxMListView;
			this.lvChildren.FullRowSelect = true;
			this.lvChildren.HideSelection = false;
			this.lvChildren.Location = new System.Drawing.Point(152, 8);
			this.lvChildren.MultiSelect = false;
			this.lvChildren.Name = "lvChildren";
			this.lvChildren.Size = new System.Drawing.Size(480, 280);
			this.lvChildren.TabIndex = 14;
			this.lvChildren.UseCompatibleStateImageBehavior = false;
			this.lvChildren.View = System.Windows.Forms.View.Details;
			this.lvChildren.ItemActivate += new System.EventHandler(this.btnEdit_Click);
			this.lvChildren.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
			this.lvChildren.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
			// 
			// colHFrom
			// 
			this.colHFrom.Text = "From";
			this.colHFrom.Width = 100;
			// 
			// colHMessage
			// 
			this.colHMessage.Text = "Message";
			this.colHMessage.Width = 250;
			// 
			// colHDate
			// 
			this.colHDate.Text = "Date";
			this.colHDate.Width = 75;
			// 
			// colHTime
			// 
			this.colHTime.Text = "Time";
			// 
			// colHTo
			// 
			this.colHTo.Text = "To";
			this.colHTo.Width = 100;
			// 
			// colHFileName
			// 
			this.colHFileName.Text = "FileName";
			// 
			// ctxMListView
			// 
			this.ctxMListView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuListViewView,
            this.mnuListViewEdit});
			// 
			// mnuListViewView
			// 
			this.mnuListViewView.Index = 0;
			this.mnuListViewView.Text = "&View";
			this.mnuListViewView.Click += new System.EventHandler(this.mnuListViewView_Click);
			// 
			// mnuListViewEdit
			// 
			this.mnuListViewEdit.Index = 1;
			this.mnuListViewEdit.Text = "&Edit";
			this.mnuListViewEdit.Click += new System.EventHandler(this.mnuListViewEdit_Click);
			// 
			// btnRefresh
			// 
			this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnRefresh.Location = new System.Drawing.Point(552, 392);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(75, 23);
			this.btnRefresh.TabIndex = 30;
			this.btnRefresh.Text = "Refresh";
			this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
			// 
			// btnEdit
			// 
			this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnEdit.Enabled = false;
			this.btnEdit.Location = new System.Drawing.Point(552, 360);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(75, 23);
			this.btnEdit.TabIndex = 29;
			this.btnEdit.Text = "Edit";
			this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
			// 
			// btnAdd
			// 
			this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnAdd.Enabled = false;
			this.btnAdd.Location = new System.Drawing.Point(552, 328);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(75, 23);
			this.btnAdd.TabIndex = 28;
			this.btnAdd.Text = "Add";
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnRename
			// 
			this.btnRename.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnRename.Location = new System.Drawing.Point(552, 296);
			this.btnRename.Name = "btnRename";
			this.btnRename.Size = new System.Drawing.Size(75, 23);
			this.btnRename.TabIndex = 27;
			this.btnRename.Text = "Rename";
			this.btnRename.Click += new System.EventHandler(this.btnRename_Click);
			// 
			// txtMessage
			// 
			this.txtMessage.Anchor = ((System.Windows.Forms.AnchorStyles) (((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txtMessage.Location = new System.Drawing.Point(360, 296);
			this.txtMessage.Multiline = true;
			this.txtMessage.Name = "txtMessage";
			this.txtMessage.ReadOnly = true;
			this.txtMessage.Size = new System.Drawing.Size(184, 120);
			this.txtMessage.TabIndex = 26;
			// 
			// lblTime
			// 
			this.lblTime.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblTime.Location = new System.Drawing.Point(200, 392);
			this.lblTime.Name = "lblTime";
			this.lblTime.Size = new System.Drawing.Size(152, 23);
			this.lblTime.TabIndex = 25;
			// 
			// lblDate
			// 
			this.lblDate.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblDate.Location = new System.Drawing.Point(200, 360);
			this.lblDate.Name = "lblDate";
			this.lblDate.Size = new System.Drawing.Size(152, 23);
			this.lblDate.TabIndex = 24;
			// 
			// lblFrom
			// 
			this.lblFrom.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblFrom.Location = new System.Drawing.Point(200, 296);
			this.lblFrom.Name = "lblFrom";
			this.lblFrom.Size = new System.Drawing.Size(152, 23);
			this.lblFrom.TabIndex = 23;
			// 
			// lblTo
			// 
			this.lblTo.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblTo.Location = new System.Drawing.Point(200, 328);
			this.lblTo.Name = "lblTo";
			this.lblTo.Size = new System.Drawing.Size(152, 23);
			this.lblTo.TabIndex = 22;
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label4.Location = new System.Drawing.Point(152, 392);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(40, 23);
			this.label4.TabIndex = 21;
			this.label4.Text = "Time:";
			// 
			// label3
			// 
			this.label3.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label3.Location = new System.Drawing.Point(152, 360);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(40, 23);
			this.label3.TabIndex = 20;
			this.label3.Text = "Date:";
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label2.Location = new System.Drawing.Point(152, 296);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(40, 23);
			this.label2.TabIndex = 19;
			this.label2.Text = "From:";
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label1.Location = new System.Drawing.Point(152, 328);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(40, 23);
			this.label1.TabIndex = 18;
			this.label1.Text = "To:";
			// 
			// statusBar
			// 
			this.statusBar.Location = new System.Drawing.Point(0, 424);
			this.statusBar.Name = "statusBar";
			this.statusBar.Size = new System.Drawing.Size(632, 22);
			this.statusBar.TabIndex = 31;
			// 
			// progressBar
			// 
			this.progressBar.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.progressBar.Location = new System.Drawing.Point(184, 212);
			this.progressBar.Name = "progressBar";
			this.progressBar.Size = new System.Drawing.Size(264, 23);
			this.progressBar.TabIndex = 32;
			this.progressBar.Visible = false;
			// 
			// MainBoard2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(632, 446);
			this.Controls.Add(this.progressBar);
			this.Controls.Add(this.statusBar);
			this.Controls.Add(this.btnRefresh);
			this.Controls.Add(this.btnEdit);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.btnRename);
			this.Controls.Add(this.txtMessage);
			this.Controls.Add(this.lblTime);
			this.Controls.Add(this.lblDate);
			this.Controls.Add(this.lblFrom);
			this.Controls.Add(this.lblTo);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lvChildren);
			this.Controls.Add(this.tvParents);
			this.Menu = this.mainMenu;
			this.MinimumSize = new System.Drawing.Size(640, 480);
			this.Name = "MainBoard2";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "MainBoard2";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.MainBoard2_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}
		#endregion

		#region Member Variables
		/// <summary>Location of folder containing subfolders representing phones.</summary>
		private static readonly string path;
		/// <summary>List view sorter.</summary>
		private DateTimeListViewColumnSorter lvwColumnSorter = new DateTimeListViewColumnSorter(2, 3);
		/// <summary>Cache of loaded contacts, keyed by number.</summary>
		private Hashtable contacts;
		/// <summary>Name of contacts directory, with path.</summary>
		private string contactDir;
		/// <summary>Cache of listviewitems representing messages, keyed by location.</summary>
		private Hashtable messageCache = new Hashtable();
		#endregion

		#region Features
		/// <summary>Adds list view items to lvChildren for each appropriate message file in the given location.</summary>
		/// <param name="path">Location of message files.</param>
		/// <param name="format">Format of files in the given location.</param>
		private void AddListViewItems(string path, MessageFormats.MessageFormat format)
		{
			string[] files;
			ListViewItem[] items;

			progressBar.Visible = true;
			files = Directory.GetFiles(path,"*."+MessageFormats.GetExtention(format));
			progressBar.Maximum = files.Length;
			progressBar.Value = 0;

			lvChildren.Items.Clear();
			foreach (string str in files)
			{
				lvChildren.Items.Add(CreateListViewItem(str, format));
				progressBar.Value++;
			}
			progressBar.Visible = false;
			items = new ListViewItem[lvChildren.Items.Count];
			for (int i =0; i<lvChildren.Items.Count;i++)
			{
				items[i] = lvChildren.Items[i];
			}

			messageCache[path] = items;
		}

		/// <summary>Create ListViewItem for the given file.</summary>
		/// <param name="filePath">Location of message file.</param>
		/// <param name="format">Format of message file.</param>
		/// <returns>ListViewItem representing the message.</returns>
		private ListViewItem CreateListViewItem(string filePath, MessageFormats.MessageFormat format)
		{
			TextMessage message = TextMessage.ReadTextMessage(filePath, format);

			string[] messageItems = new string[6];
			if (message.Status == MessageStatus.Recieved) {
				messageItems[0] = message.Number;
			} else {
				messageItems[4] = message.Number;
			}
			messageItems[1] = message.Message;
			messageItems[2] = message.DateTime.Date.ToShortDateString();
			messageItems[3] = message.DateTime.TimeOfDay.ToString();

			messageItems[5] = Path.GetFileName(filePath);
			ListViewItem result = new ListViewItem(messageItems);

			return result;
		}

		/// <summary>Determine MessageFormat of the given node.</summary>
		/// <param name="node">The node to find the format for.</param>
		/// <returns>The found MessageFormat.</returns>
		protected virtual MessageFormats.MessageFormat FindFormat(TreeNode node)
		{
			MessageFormats.MessageFormat format;

			if (node.Tag is MessageFormats.MessageFormat)
			{
				format = (MessageFormats.MessageFormat)node.Tag;
			}
			else	
			{
				if (node.Parent != null)
				{
					format = FindFormat(node.Parent);
				}
				else	
				{
					format = (MessageFormats.MessageFormat)(-1);
				}
			}

			return format;
		}

		/// <summary>Creates the path for the given node.</summary>
		/// <param name="node">The node to create the path for.</param>
		/// <returns>The path for the node.</returns>
		protected virtual string CreateNodePath(TreeNode node)
		{
			string result;

//			if (node.Parent == null)
//			{
//				result = node.Text;
//			}
//			else 
			if (node.Tag is MessageFormats.MessageFormat)
			{
				result = path +"\\" +node.Text +"\\";
			}
			else	
			{
				result = CreateNodePath(node.Parent)+node.Text +"\\";
			}

			return result;
		}
		
		/// <summary>Refreshes the given node.</summary>
		/// <remarks>Clears the cache for this and sub nodes, and recreates the listviewitems for this node.</remarks>
		/// <param name="node">The node to refresh.</param>
		protected virtual void RefreshNode(TreeNode node)
		{
			string nodePath;

			statusBar.Text = "Refreshing...";
			Cursor.Current = Cursors.WaitCursor;
			nodePath = CreateNodePath(node);

			//remove cache for all sub items
			List<string> keysToRemove = new List<string>();
			foreach(string key in messageCache.Keys)
			{
				if (key.StartsWith(nodePath))
				{
					keysToRemove.Add(key);
				}
			}
			foreach (string key in keysToRemove)
			{
				messageCache.Remove(key);
			}
			node.Nodes.Clear();

			//phone/subfolder node
			string[] folders = Directory.GetDirectories(nodePath), pathSplit;
			string displayString;

			Array.Sort((System.Array)folders);
			foreach	(string str in folders)
			{
				pathSplit = str.Split(new char[]{'\\'});
				displayString = pathSplit[pathSplit.Length -1];
				node.Nodes.Add(displayString);
			}

			lvChildren.Items.Clear();

			//list view items:
			lvChildren.BeginUpdate();
			lvChildren.Items.Clear();
			//messageCache.Remove(nodePath);
			AddListViewItems(nodePath, FindFormat(node));
			lvChildren.EndUpdate();

			SetNodeStatus(node);
			Cursor.Current = Cursors.Default;

		}

		/// <summary>Sets the text of the status bar wrt the given node.</summary>
		/// <param name="node">The node to set the status wrt.</param>
		protected virtual void SetNodeStatus(TreeNode node)
		{
			if (node.Tag != null)
			{
				statusBar.Text = "Phone: " + CreateNodePath(node);
			}
			else
			{
				statusBar.Text = node.Text;
			}
			if (lvChildren.Items.Count>0)
			{
				statusBar.Text += "["+ lvChildren.Items.Count + " messages]";
			}
		}
		
		/// <summary>Populate the contacts member, with vcf files from the contactsDir.
		/// Keyed by number.</summary>
		protected virtual void CreateContacts()
		{
			Hashtable contactsTmp = vCardReader.vCardReader.ReadVCardDirectory(contactDir);
			contacts = new Hashtable();
			
			//extract numbers from contact details
			foreach(string contactName in contactsTmp.Keys)
			{
				//get contact details
				Hashtable contactDetails = (Hashtable)contactsTmp[contactName];
				if (contactDetails.ContainsKey("TEL"))
				{
					//get contact numbers, if they have any
					Hashtable contactNumbers = (Hashtable)contactDetails["TEL"];
					foreach (Hashtable numberCategory in contactNumbers.Values)
					{
						//contacts can have multiple categories of numbers (HOME, WORK, etc)
						foreach (string[] contactCategoryNumbers in numberCategory.Values)
						{
							foreach (string contactNumber in contactCategoryNumbers)
							{
								string convertedNumber = contactNumber;
								//TODO: perhaps the following should be performed within vCardReader
								//if number starts with a '+(44)', remove it and replace with a '0'
								if (convertedNumber.IndexOf('+')!=-1)
								{
									convertedNumber = "0"+convertedNumber.Substring(convertedNumber.Length -10);
								}
								//store the number as a key with value of the contact name
								contacts[convertedNumber] = contactName;
							}
						}
					}
				}
			}

			string nameFrom, nameTo, numberFrom, numberTo;
			ListView lstView = lvChildren;
			//Add names of contacts in a different column
			foreach (ListViewItem lvi in lstView.Items)
			{
				numberFrom = lvi.SubItems[0].Text;
				numberTo = lvi.SubItems[4].Text;
				if (!contacts.ContainsKey(numberFrom) && numberFrom.StartsWith("+") && numberFrom.Length > 10)
					numberFrom = "0"+numberFrom.Substring(numberFrom.Length - 10);
				if (!contacts.ContainsKey(numberTo) &&numberTo.StartsWith("+") && numberTo.Length > 10)
					numberTo = "0"+numberTo.Substring(numberTo.Length -10);
				nameFrom = (string)contacts[numberFrom];
				nameTo = (string)contacts[numberTo];
				if (nameFrom!= null && nameFrom!="")
				{
					lvi.SubItems[0].Text = nameFrom+"("+numberFrom+")";
				}
				if (nameTo!= null && nameTo!="")
				{
					lvi.SubItems[4].Text = nameTo+"("+numberTo+")";
				}
			}
		}
		#endregion

		#region Event Handlers
		private void mnuExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void mnuNo2Names_Click(object sender, System.EventArgs e)
		{
			// Changes numbers of any recognised numbers from contacts cache into the listviewitem.
			FolderBoard frm;
			DialogResult dr = DialogResult.None;

			frm = (FolderBoard)this.ActiveMdiChild;
			FolderBrowserDialog fbd = new FolderBrowserDialog();
			if (/*contacts != null && */contactDir != null && contactDir != "")
			{
				fbd.SelectedPath = contactDir;
				//ask user if they wish to use previous contacts list
				if (MessageBox.Show("Use previous contact list?","Question",MessageBoxButtons.YesNo) ==	DialogResult.No)
				{
					dr = fbd.ShowDialog();
				}
			}
			else
			{
				dr = fbd.ShowDialog();
			}
			if (dr != DialogResult.Cancel)//dr == DialogResult.OK || dr == DialogResult.No)
			{
				CreateContacts();
			}
			//				else
			//				{
			//					MessageBox.Show("Operation Cancelled","Warning",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
			//				}
		}
		private void listView1_ColumnClick(object sender, System.Windows.Forms.ColumnClickEventArgs e)
		{
			ListViewColumnSorter.SortListView(lvChildren, e.Column);
		}

		private void listView1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			//update appropriate controls wrt selected listviewitem
			if (lvChildren.SelectedItems.Count >0)
			{
				ListViewItem items = lvChildren.SelectedItems[0];
				lblFrom.Text = items.SubItems[0].Text;
				txtMessage.Text = items.SubItems[1].Text;
				lblDate.Text = items.SubItems[2].Text;
				lblTime.Text = items.SubItems[3].Text;
				lblTo.Text = items.SubItems[4].Text;
				btnEdit.Enabled = true;
			}
			else
			{
				lblFrom.Text = "";
				txtMessage.Text = "";
				lblDate.Text = "";
				lblTime.Text = "";
				lblTo.Text = "";
				btnEdit.Enabled = false;
			}
			//disable edit for consolidated view from parent nodes (top most node and phone nodes)
			btnEdit.Enabled &= tvParents.SelectedNode.Parent !=null ^ tvParents.SelectedNode.Tag != null;
		}
		private void MainBoard2_Load(object sender, System.EventArgs e)
		{
			//IDictionary tmp = (IDictionary) ConfigurationSettings.GetConfig("InitialFolder");

			//string[] phones = Directory.GetDirectories(path), pathSplit, displayString;
			TreeNode node;

			contactDir =ConfigurationSettings.AppSettings["Contacts"];

			NameValueCollection phones = (NameValueCollection)ConfigurationSettings.GetConfig("Phones");
			
			//load initial nodes from config file
			foreach	(string phoneName in phones.Keys)
			{
				MessageFormats.MessageFormat format = (MessageFormats.MessageFormat) Enum.Parse(typeof(MessageFormats.MessageFormat), phones[phoneName]);
				MobilePhone phone = new MobilePhone(phoneName, format);
				node = tvParents.Nodes[0].Nodes.Add(phoneName);
				node.Tag = format;
				tvParents.SelectedNode = node;//select each node to add the folders
			}
			tvParents.SelectedNode = tvParents.Nodes[0];
			lvChildren.ListViewItemSorter = lvwColumnSorter;
		}

		private void tvParents_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			//set controls to display appropriately wrt selected node.
			string nodePath;

			lvChildren.BeginUpdate();

			btnRefresh.Enabled = true;
			if (e.Node.Parent == null)
			{
				//top level node
				lvChildren.Items.Clear();
				//show any messages that have been cached
				foreach (ListViewItem[] items in messageCache.Values)
				{
					lvChildren.Items.AddRange(items);
				}
				SetNodeStatus(e.Node);
				btnAdd.Enabled = false;
				btnEdit.Enabled = false;
				btnRefresh.Enabled = false;
			}
			else if (e.Node.Tag == null || e.Node.Nodes.Count == 0)
			{
				//phone node with no children or folder node
				nodePath = CreateNodePath(e.Node);
				if (!messageCache.ContainsKey(nodePath))
				{
					RefreshNode(e.Node);
				}
				else
				{
					lvChildren.Items.Clear();
					lvChildren.Items.AddRange((ListViewItem[])messageCache[nodePath]);
					SetNodeStatus(e.Node);
				}
				btnAdd.Enabled = true;
			}
			else if (e.Node.Tag != null)
			{
				//phone node
				btnAdd.Enabled = false;
				lvChildren.Items.Clear();
				nodePath = CreateNodePath(e.Node);
				//show any cached messages for this phone
				foreach (string key in messageCache.Keys)
				{
					if (key.IndexOf(nodePath)!=-1)
					{
						lvChildren.Items.AddRange((ListViewItem[])messageCache[key]);
					}
				}
				SetNodeStatus(e.Node);
			}

			lvChildren.EndUpdate();
		}

		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			//
			string fileNumber = lvChildren.Items.Count.ToString();
			string filePath = path+"\\"+tvParents.SelectedNode.FullPath.Substring(tvParents.Nodes[0].Text.Length+1)+"\\";
			MessageFormats.MessageFormat format = FindFormat(tvParents.SelectedNode);

			if (format == MessageFormats.MessageFormat.Motorola)
			{
				fileNumber = fileNumber.PadLeft(4, '0');
			}
			string nextFile =MessageFormats.GetFilePrefix(format) + fileNumber +"." + MessageFormats.GetExtention(format);
			NewEditMessage f3 = new NewEditMessage(filePath, nextFile, "add", format);
			if (f3.ShowDialog(this) != DialogResult.Cancel)
			{
				ListViewItem lvi = CreateListViewItem(filePath+"\\"+nextFile, format);
				lvChildren.Items.Add(lvi);
				lvChildren.Sort();
				//TODO: update cache
				//add to cache
			}
		}

		private void btnEdit_Click(object sender, System.EventArgs e)
		{
			string filePath = path+"\\"+tvParents.SelectedNode.FullPath.Substring(tvParents.Nodes[0].Text.Length+1)+"\\";
			//MessageFormats.MessageFormat format = (MessageFormats.MessageFormat)tvParents.SelectedNode.Parent.Tag;
			MessageFormats.MessageFormat format = FindFormat(tvParents.SelectedNode);
			ListViewItem lvi = lvChildren.SelectedItems[0];
			NewEditMessage f3 = new NewEditMessage(filePath, lvi.SubItems[5].Text, lvi, format);

			if (f3.ShowDialog(this) != DialogResult.Cancel)
			{
				ListViewItem lvi2 = CreateListViewItem(filePath+"\\"+lvi.SubItems[5].Text, format);
				lvChildren.Items.Insert(lvi.Index, lvi2);
				lvi.Remove();
				lvChildren.Sort();

				//TODO: update cache
				//remove from cache
				//add to cache
			}
		}

		private void btnRename_Click(object sender, System.EventArgs e)
		{
			InputForm input = new InputForm("Enter start index:", "Start Index");
			if (input.ShowDialog(this) == DialogResult.OK)
			{
				int n = 0;
				string startIndex = input.InputText;
				try
				{
					n = int.Parse(startIndex);
				}
				catch(FormatException)
				{
					MessageBox.Show("That is not a valid number.\n 0 will be used as the start index", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				}

				string subfolder = "Renamed\\",filename, fileNumber;//path = this.Text+"\\"
				bool doIt = true;
				MessageFormats.MessageFormat format = FindFormat(tvParents.SelectedNode);
				string path = MainBoard2.path+"\\"+tvParents.SelectedNode.FullPath.Substring(tvParents.Nodes[0].Text.Length+1)+"\\";

				if (Directory.Exists(path+subfolder))
				{
					doIt = false;
					DialogResult dr = MessageBox.Show("Overwrite existing directory and files","Warning",MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
					if (dr == DialogResult.OK)
					{
						doIt = true;
						Directory.Delete(path+subfolder,true);
					}
					else
					{
						MessageBox.Show("Operation Aborted");
					}
				}
				if (doIt)
				{
					Directory.CreateDirectory(path+subfolder);
					foreach (ListViewItem lvi in lvChildren.Items)
					{
						filename = lvi.SubItems[5].Text;
						fileNumber = n.ToString();
						if (format == MessageFormats.MessageFormat.Motorola)
						{
							fileNumber = fileNumber.PadLeft(4,'0');
						}
						File.Copy(path+filename,path+subfolder+MessageFormats.GetFilePrefix(format)+fileNumber+"." + MessageFormats.GetExtention(format));
						n++;
					}
				}
				//File.Move(txtPath.Text+txtOrigFileName.Text,txtPath.Text+txtNewFileName.Text);
				//File.Delete(txtPath.Text+txtOrigFileName.Text);
			}
		}

		private void btnRefresh_Click(object sender, System.EventArgs e)
		{
			RefreshNode(tvParents.SelectedNode);
		}

		private void mnuCreateNew_Click(object sender, System.EventArgs e)
		{
			TreeNode node = (TreeNode)tvParents.Tag;

			tvParents.Tag = null;

			string nodePth = CreateNodePath(node), newName;

			InputForm input = new InputForm("Enter name for new folder:","New Folder");
			if (input.ShowDialog(this) == DialogResult.OK)
			{
				newName	= input.InputText;
				Directory.CreateDirectory(nodePth + newName);
				RefreshNode(node);
			}
		}
		private void ctxMTreeview_Popup(object sender, System.EventArgs e)
		{
			TreeNode node;

			node = tvParents.GetNodeAt(tvParents.PointToClient(MousePosition));

			if (node.Parent == null)
			{
				mnuCreateNew.Enabled = false;
			}
			else	
			{
				mnuCreateNew.Enabled = true;
			}
			tvParents.Tag = node;//don't want to select the node, but need to pass it to the menu click
		}

		private void mnuShowContacts_Click(object sender, System.EventArgs e)
		{
			if (contacts == null)
			{
				CreateContacts();
			}
			HashtableViewer.HashtableViewer form = new HashtableViewer.HashtableViewer(contacts);
			form.Show();
		}

		private void mnuReadAccessDatabase_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog openDialog = new OpenFileDialog();
			openDialog.Filter = "Access Database (*.mdb)|*.MDB";

			if (openDialog.ShowDialog(this) == DialogResult.OK)
			{
				AccessDatabaseMessages accessDBMessages = new AccessDatabaseMessages(openDialog.FileName);
				accessDBMessages.Show();
			}
		}

		private void mnuListViewView_Click(object sender, System.EventArgs e)
		{
			foreach(ListViewItem item in lvChildren.SelectedItems)
			{
				string filePath =path + tvParents.SelectedNode.FullPath.Substring("Phones".Length) +"\\"+item.SubItems[5].Text;
				//Perhaps this should allow the default application to open the file
				//System.Diagnostics.Process.Start("notepad", filePath);
				System.Diagnostics.Process.Start(filePath);
			}
		}

		private void mnuListViewEdit_Click(object sender, System.EventArgs e)
		{
			btnEdit_Click(sender, e);
		}
		#endregion
	}
}
